ascension_armor = class( {} )

LinkLuaModifier( "modifier_ascension_armor", "modifiers/modifier_ascension_armor", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ascension_armor:GetIntrinsicModifierName()
	return "modifier_ascension_armor"
end

--------------------------------------------------------------------------------
