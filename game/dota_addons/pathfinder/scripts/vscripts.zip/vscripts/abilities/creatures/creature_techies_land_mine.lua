
creature_techies_land_mine = class({})
LinkLuaModifier( "modifier_creature_techies_land_mine", "modifiers/creatures/modifier_creature_techies_land_mine", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function creature_techies_land_mine:OnSpellStart()
	if IsServer() then
		
	end
end

--------------------------------------------------------------------------------
