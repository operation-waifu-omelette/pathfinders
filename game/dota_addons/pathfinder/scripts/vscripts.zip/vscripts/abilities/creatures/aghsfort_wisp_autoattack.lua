
aghsfort_wisp_autoattack = class({})
LinkLuaModifier( "modifier_aghsfort_wisp_autoattack", "modifiers/creatures/modifier_aghsfort_wisp_autoattack", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function aghsfort_wisp_autoattack:GetIntrinsicModifierName()
	return "modifier_aghsfort_wisp_autoattack"
end

-----------------------------------------------------------------------------------------
