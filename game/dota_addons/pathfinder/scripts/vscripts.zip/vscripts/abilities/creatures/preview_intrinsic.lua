
preview_intrinsic = class({})
LinkLuaModifier( "modifier_ability_cast_warning", "modifiers/modifier_ability_cast_warning", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function preview_intrinsic:GetIntrinsicModifierName()
	return "modifier_ability_cast_warning"
end

-----------------------------------------------------------------------------------------
