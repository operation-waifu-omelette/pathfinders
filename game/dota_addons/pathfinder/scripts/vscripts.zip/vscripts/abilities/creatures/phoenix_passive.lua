phoenix_passive = class( {} )

LinkLuaModifier( "modifier_phoenix_passive", "modifiers/creatures/modifier_phoenix_passive", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function phoenix_passive:GetIntrinsicModifierName()
	return "modifier_phoenix_passive"
end

--------------------------------------------------------------------------------
