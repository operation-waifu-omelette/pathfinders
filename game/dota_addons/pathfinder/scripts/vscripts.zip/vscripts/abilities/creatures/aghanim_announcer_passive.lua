
aghanim_announcer_passive = class({})

LinkLuaModifier( "modifier_aghanim_announcer_passive", "modifiers/creatures/modifier_aghanim_announcer_passive", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function aghanim_announcer_passive:GetIntrinsicModifierName()
	return "modifier_aghanim_announcer_passive"
end

--------------------------------------------------------------------------------

