
brewmaster_unit_passive = class({})
LinkLuaModifier( "modifier_brewmaster_unit_passive", "modifiers/creatures/modifier_brewmaster_unit_passive", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function brewmaster_unit_passive:GetIntrinsicModifierName()
	return "modifier_brewmaster_unit_passive"
end

-----------------------------------------------------------------------------------------

