ability_ascension = class( {} )

LinkLuaModifier( "modifier_ascension", "modifiers/modifier_ascension", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ability_ascension:GetIntrinsicModifierName()
	return "modifier_ascension"
end

--------------------------------------------------------------------------------
