
modifier_boss_visage_thinker_dummy = class({})
