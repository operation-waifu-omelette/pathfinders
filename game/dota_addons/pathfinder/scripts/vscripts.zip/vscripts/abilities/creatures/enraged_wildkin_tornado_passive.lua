
enraged_wildkin_tornado_passive = class({})
LinkLuaModifier( "modifier_enraged_wildkin_tornado_passive", "modifiers/creatures/modifier_enraged_wildkin_tornado_passive", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function enraged_wildkin_tornado_passive:GetIntrinsicModifierName()
	return "modifier_enraged_wildkin_tornado_passive"
end

-----------------------------------------------------------------------------------------
