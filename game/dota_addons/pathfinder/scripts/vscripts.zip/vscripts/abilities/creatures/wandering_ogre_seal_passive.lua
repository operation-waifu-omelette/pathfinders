
wandering_ogre_seal_passive = class({})
LinkLuaModifier( "modifier_wandering_ogre_seal", "modifiers/creatures/modifier_wandering_ogre_seal", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function wandering_ogre_seal_passive:GetIntrinsicModifierName()
	return "modifier_wandering_ogre_seal"
end

--------------------------------------------------------------------------------
