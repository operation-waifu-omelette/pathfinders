
huge_brood_passive = class({})
LinkLuaModifier( "modifier_huge_brood_passive", "modifiers/creatures/modifier_huge_brood_passive", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function huge_brood_passive:GetIntrinsicModifierName()
	return "modifier_huge_brood_passive"
end

-----------------------------------------------------------------------------------------
