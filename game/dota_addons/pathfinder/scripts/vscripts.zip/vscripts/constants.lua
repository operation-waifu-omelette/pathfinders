
-- General Game Mode Config
_G.AGHANIM_PLAYERS = 4

_G.player_patron_level = {0,0,0,0}
_G.player_points = {0,0,0,0}
_G.player_couriers = {191,185,189,1}

_G.AUTH = "1DC09B13FDCED52144B227E9D43AB8405C818584"--"BAD"
if IsDedicatedServer() and not GameRules:IsCheatMode() then
	_G.AUTH = GetDedicatedServerKeyV2("pathfinder")
end

_G.SERVER_LOCATION = "https://pathfinder-93b49.firebaseio.com/" .. _G.AUTH .. "/users/"
-- _G.SERVER_LOCATION = "https://pathfinder-93b49.firebaseio.com/users/"

_G.HERO_LIST =  {			"npc_dota_hero_disruptor"				,
							"npc_dota_hero_magnataur"				,
							"npc_dota_hero_mars"					,
							"npc_dota_hero_snapfire"				,
							"npc_dota_hero_sniper"					,
							"npc_dota_hero_tusk"					,
							"npc_dota_hero_ursa"					,
							"npc_dota_hero_viper"					,
							"npc_dota_hero_weaver"					,
							"npc_dota_hero_winter_wyvern"			,
							"npc_dota_hero_omniknight"				,
							"npc_dota_hero_witch_doctor"			,
							"npc_dota_hero_templar_assassin"		,
							"npc_dota_hero_slark"					,
							"npc_dota_hero_queenofpain"				,
							"npc_dota_hero_windrunner"				,	
							"npc_dota_hero_phantom_assassin"		,
							"npc_dota_hero_legion_commander"		,	
							"npc_dota_hero_juggernaut"				,
							"npc_dota_hero_venomancer",}	

_G.AGHANIM_TIMED_RESPAWN_MODE = true
_G.AGHANIM_TIMED_RESPAWN_TIME = 10.0

_G.AGHANIM_STARTING_LIVES = 2
_G.AGHANIM_MAX_LIVES = 3

_G.AGHANIM_STARTING_GOLD = 670
_G.AGHANIM_STARTING_SALVES = 1
_G.AGHANIM_STARTING_MANGOES = 0
_G.AGHANIM_ENABLE_BOTTLE = true
_G.AGHANIM_ENCOUNTER_BOTTLE_CHARGES = 1

_G.AGHANIM_ASCENSION_APPRENTICE = 0
_G.AGHANIM_ASCENSION_MAGICIAN = 1
_G.AGHANIM_ASCENSION_SORCERER = 2
_G.AGHANIM_ASCENSION_GRAND_MAGUS = 3
_G.AGHANIM_ASCENSION_APEX_MAGE = 4

_G.AGHANIM_TRIAL_ASCENSION = AGHANIM_ASCENSION_GRAND_MAGUS

_G.LIFE_REVIVE_COST = 1
_G.LIFE_BUYBACK_COST = 2
_G.REVIVE_HEALTH_PCT = 100
_G.REVIVE_MANA_PCT = 100

_G.GOLD_BAG_DROP_PCT = 33
_G.HEALTH_POTION_DROP_PCT = 2
_G.MANA_POTION_DROP_PCT = 2
_G.HEAL_ON_ENCOUNTER_COMPLETE = true

_G.NUM_VIABLE_ROOMS_FOR_DROPPED_ITEMS = 11
_G.PCT_BASE_TWO_ITEM_DROP = 0
_G.NUM_NEUTRAL_ITEMS_DROPPED = 12
_G.PCT_BASE_NEUTRAL_ITEM_DROP = 16
_G.NUM_CONSUMABLES_FROM_ROOM_REWARD = 2

_G.NUM_LIVES_FROM_BOSSES = 0

-- Audio
_G.VOICE_LAUGH_COOLDOWN = 20.0
_G.VOICE_PERIODIC_TAUNT_COOLDOWN = 35.0
_G.VOICE_LINE_COOLDOWN = 4.0
_G.VOICE_VOLUME = 1.6

-- Atlas 
_G.ROOM_TYPE_INVALID = 0
_G.ROOM_TYPE_STARTING = 1
_G.ROOM_TYPE_ENEMY = 2
_G.ROOM_TYPE_TRAPS = 3
_G.ROOM_TYPE_BOSS = 4
_G.ROOM_TYPE_TRANSITIONAL = 5
_G.ROOM_TYPE_BONUS = 6

_G.RoomTypeStrings = {}

RoomTypeStrings[ ROOM_TYPE_ENEMY ]= "ROOM_TYPE_ENEMY"
RoomTypeStrings[ ROOM_TYPE_BOSS ] = "ROOM_TYPE_BOSS"
RoomTypeStrings[ ROOM_TYPE_STARTING ] = "ROOM_TYPE_STARTING"
RoomTypeStrings[ ROOM_TYPE_TRAPS ] = "ROOM_TYPE_TRAPS"
RoomTypeStrings[ ROOM_TYPE_TRANSITIONAL ] = "ROOM_TYPE_TRANSITIONAL"
RoomTypeStrings[ ROOM_TYPE_BONUS ] = "ROOM_TYPE_BONUS"


function GetStringForRoomType( nType )
	return _G.RoomTypeStrings[ nType ]
end

-- Room Exit directions
_G.ROOM_EXIT_LEFT = 0
_G.ROOM_EXIT_TOP = 1
_G.ROOM_EXIT_RIGHT = 2

-- these are only used for UI purposes.
_G.ROOM_EXIT_BOTTOM = 3 
_G.ROOM_EXIT_INVALID = -1

function GetEntranceDirectionForExitType( nExitDirection )
	if nExitDirection == ROOM_EXIT_LEFT then
		return ROOM_EXIT_RIGHT
	end
	if nExitDirection == ROOM_EXIT_TOP then
		return ROOM_EXIT_BOTTOM
	end
	if nExitDirection == ROOM_EXIT_RIGHT then
		return ROOM_EXIT_LEFT
	end

	-- You can never exit from the bottom
	return ROOM_EXIT_INVALID
end

-- Amount of XP earned per hero per depth (if the encounter gives XP)

-- setting this to a value greater than zero will level up every creature; increasing its max hp and attack damage
-- a value of 1.0 will increase HP by 30%, and damage by 10%; other values scale accordingly
_G.GAME_DIFFICULTY_FACTOR = 0.2

_G.DEFAULT_PORTAL_SPAWN_INTERVAL = 30
_G.PORTAL_ESCALATION_ENABLED = true
_G.PORTAL_ESCALATION_RATE = 2.5

_G.DEFAULT_MIN_CRATES_ENEMY_ENC = 8
_G.DEFAULT_MAX_CRATES_ENEMY_ENC = 10

_G.DEFAULT_MIN_CRATES_BOSS_ENC = 12
_G.DEFAULT_MAX_CRATES_BOSS_ENC = 15

_G.DEFAULT_MIN_CHESTS = 1
_G.DEFAULT_MAX_CHESTS = 2

_G.ENCOUNTER_SPAWN_BARRELS_CHANCE = 40
_G.DEFAULT_MIN_BARRELS_ENEMY_ENC = 3
_G.DEFAULT_MAX_BARRELS_ENEMY_ENC = 6

-- blessing constants
_G.BLESSING_TYPE_MODIFIER = 1
_G.BLESSING_TYPE_ITEM_GRANT = 2
_G.BLESSING_TYPE_LIFE_GRANT = 3
_G.BLESSING_TYPE_GOLD_GRANT = 4

_G.TIME_BEFORE_DETECT_INVIS = 300
_G.TIME_BEFORE_PROVIDE_VISION = 300