
modifier_elemental_tiny_create_io_dummy = class({})

--------------------------------------------------------------

function modifier_elemental_tiny_create_io_dummy:IsHidden()
	return true
end
