creature_pudge_miniboss_passive = class({})
LinkLuaModifier( "modifier_creature_pudge_miniboss_passive", "modifiers/creatures/modifier_creature_pudge_miniboss_passive", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function creature_pudge_miniboss_passive:GetIntrinsicModifierName()
	return "modifier_creature_pudge_miniboss_passive"
end
