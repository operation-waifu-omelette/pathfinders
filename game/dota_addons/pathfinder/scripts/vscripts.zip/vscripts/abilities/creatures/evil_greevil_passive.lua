
evil_greevil_passive = class({})
LinkLuaModifier( "modifier_evil_greevil_passive", "modifiers/creatures/modifier_evil_greevil_passive", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function evil_greevil_passive:GetIntrinsicModifierName()
	return "modifier_evil_greevil_passive"
end

-----------------------------------------------------------------------------------------

