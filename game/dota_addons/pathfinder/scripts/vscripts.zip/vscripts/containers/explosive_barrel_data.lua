
_G.ExplosiveBarrelData =
{
	{
		fSpawnChance = 0.5,
		szSpawnerName = "explosive_barrel",
		szNPCName = "npc_dota_explosive_barrel",
		nMaxSpawnDistance = 0,
	},
}
