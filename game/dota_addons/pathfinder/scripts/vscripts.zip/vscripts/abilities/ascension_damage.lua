ascension_damage = class( {} )

LinkLuaModifier( "modifier_ascension_damage", "modifiers/modifier_ascension_damage", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ascension_damage:GetIntrinsicModifierName()
	return "modifier_ascension_damage"
end

--------------------------------------------------------------------------------
