
status_resist_50 = class({})
LinkLuaModifier( "modifier_status_resist_50", "modifiers/modifier_status_resist_50", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function status_resist_50:GetIntrinsicModifierName()
	return "modifier_status_resist_50"
end
