ability_absolute_no_cc = class( {} )

LinkLuaModifier( "modifier_absolute_no_cc", "modifiers/modifier_absolute_no_cc", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ability_absolute_no_cc:GetIntrinsicModifierName()
	return "modifier_absolute_no_cc"
end

--------------------------------------------------------------------------------
