ascension_impatient = class( {} )

LinkLuaModifier( "modifier_ascension_impatient", "modifiers/modifier_ascension_impatient", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ascension_impatient:GetIntrinsicModifierName()
	return "modifier_ascension_impatient"
end

--------------------------------------------------------------------------------
