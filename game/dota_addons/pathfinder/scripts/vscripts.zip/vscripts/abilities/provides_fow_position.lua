
provides_fow_position = class({})

--------------------------------------------------------------------------------

function provides_fow_position:GetIntrinsicModifierName()
	return "modifier_provides_fow_position"
end

--------------------------------------------------------------------------------
