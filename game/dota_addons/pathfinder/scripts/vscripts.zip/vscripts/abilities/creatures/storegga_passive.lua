
storegga_passive = class({})
LinkLuaModifier( "modifier_storegga_passive", "modifiers/creatures/modifier_storegga_passive", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function storegga_passive:GetIntrinsicModifierName()
	return "modifier_storegga_passive"
end

-----------------------------------------------------------------------------------------
