ascension_magic_resist = class( {} )

LinkLuaModifier( "modifier_ascension_magic_resist", "modifiers/modifier_ascension_magic_resist", LUA_MODIFIER_MOTION_NONE )

--------------------------------------------------------------------------------

function ascension_magic_resist:GetIntrinsicModifierName()
	return "modifier_ascension_magic_resist"
end

--------------------------------------------------------------------------------
