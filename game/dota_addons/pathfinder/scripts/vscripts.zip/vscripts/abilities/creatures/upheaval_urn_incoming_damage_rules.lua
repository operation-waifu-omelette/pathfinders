
upheaval_urn_incoming_damage_rules = class({})
LinkLuaModifier( "modifier_upheaval_urn_incoming_damage_rules", "modifiers/creatures/modifier_upheaval_urn_incoming_damage_rules", LUA_MODIFIER_MOTION_NONE )

-----------------------------------------------------------------------------------------

function upheaval_urn_incoming_damage_rules:GetIntrinsicModifierName()
	return "modifier_upheaval_urn_incoming_damage_rules"
end

-----------------------------------------------------------------------------------------
